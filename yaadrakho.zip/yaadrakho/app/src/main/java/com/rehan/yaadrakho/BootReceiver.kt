package com.rehan.yaadrakho

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        if (i.action != Intent.ACTION_BOOT_COMPLETED) return
        val now = System.currentTimeMillis()
        for (t in Store.tasks(c)) {
            if (t.done) continue
            val at = if (t.whenMs > now) t.whenMs else now + 10_000L
            Scheduler.scheduleTask(c, t, at, 0)
        }
        Scheduler.scheduleNight(c)
    }
}
