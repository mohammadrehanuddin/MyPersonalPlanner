package com.rehan.yaadrakho

import android.app.NotificationManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class ActionReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        val nm = c.getSystemService(NotificationManager::class.java)
        val kind = i.getStringExtra("kind")
        val id = i.getLongExtra("id", 0L)
        when (i.action) {
            "DONE" -> {
                if (kind == "task") {
                    Store.markDone(c, id)
                    Scheduler.cancelTask(c, id)
                    nm.cancel(Scheduler.rc(id))
                } else {
                    Scheduler.cancelBooksRepeat(c)
                    nm.cancel(Notifier.BOOKS_NOTIF)
                }
            }
            "SNOOZE" -> {
                val t = Store.find(c, id)
                if (t != null) {
                    Scheduler.scheduleTask(c, t, System.currentTimeMillis() + Scheduler.SNOOZE_MS, 0)
                }
                nm.cancel(Scheduler.rc(id))
            }
        }
    }
}
