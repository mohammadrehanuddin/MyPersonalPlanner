package com.rehan.yaadrakho

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import java.util.Calendar

object Scheduler {
    const val REPEAT_TASK_MS = 5 * 60 * 1000L
    const val REPEAT_BOOKS_MS = 15 * 60 * 1000L
    const val SNOOZE_MS = 10 * 60 * 1000L
    const val MAX_TASK_REPEATS = 12
    const val MAX_BOOKS_REPEATS = 4

    private const val NIGHT_CODE = 1
    private const val BOOKS_REPEAT_CODE = 2
    private const val FLAGS = PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE

    fun rc(id: Long): Int = id.hashCode()

    private fun am(c: Context) = c.getSystemService(Context.ALARM_SERVICE) as AlarmManager

    // setAlarmClock is exempt from battery saver / doze and needs no special permission,
    // so it is the most reliable way to ring exactly on time.
    private fun setAt(c: Context, atMs: Long, pi: PendingIntent) {
        val show = PendingIntent.getActivity(c, 0, Intent(c, MainActivity::class.java), FLAGS)
        am(c).setAlarmClock(AlarmManager.AlarmClockInfo(atMs, show), pi)
    }

    // ---------- Tasks ----------

    private fun taskPi(c: Context, id: Long, n: Int): PendingIntent {
        val i = Intent(c, AlarmReceiver::class.java)
            .putExtra("kind", "task")
            .putExtra("id", id)
            .putExtra("n", n)
        return PendingIntent.getBroadcast(c, rc(id), i, FLAGS)
    }

    fun scheduleTask(c: Context, t: Task, atMs: Long = t.whenMs, n: Int = 0) {
        setAt(c, atMs, taskPi(c, t.id, n))
    }

    fun cancelTask(c: Context, id: Long) {
        am(c).cancel(taskPi(c, id, 0))
    }

    // ---------- Nightly books reminder ----------

    private fun booksPi(c: Context, code: Int, n: Int): PendingIntent {
        val i = Intent(c, AlarmReceiver::class.java)
            .putExtra("kind", "books")
            .putExtra("n", n)
        return PendingIntent.getBroadcast(c, code, i, FLAGS)
    }

    fun scheduleNight(c: Context) {
        val cal = Calendar.getInstance()
        cal.set(Calendar.HOUR_OF_DAY, Store.nightHour(c))
        cal.set(Calendar.MINUTE, Store.nightMinute(c))
        cal.set(Calendar.SECOND, 0)
        cal.set(Calendar.MILLISECOND, 0)
        if (cal.timeInMillis <= System.currentTimeMillis()) {
            cal.add(Calendar.DAY_OF_YEAR, 1)
        }
        setAt(c, cal.timeInMillis, booksPi(c, NIGHT_CODE, 0))
    }

    fun repeatBooks(c: Context, n: Int) {
        setAt(c, System.currentTimeMillis() + REPEAT_BOOKS_MS, booksPi(c, BOOKS_REPEAT_CODE, n))
    }

    fun cancelBooksRepeat(c: Context) {
        am(c).cancel(booksPi(c, BOOKS_REPEAT_CODE, 0))
    }
}
