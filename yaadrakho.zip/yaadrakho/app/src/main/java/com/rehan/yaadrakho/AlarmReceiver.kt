package com.rehan.yaadrakho

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        when (i.getStringExtra("kind")) {
            "task" -> {
                val id = i.getLongExtra("id", 0L)
                val n = i.getIntExtra("n", 0)
                val t = Store.find(c, id) ?: return
                if (t.done) return
                Notifier.task(c, t, n)
                if (n < Scheduler.MAX_TASK_REPEATS) {
                    Scheduler.scheduleTask(c, t, System.currentTimeMillis() + Scheduler.REPEAT_TASK_MS, n + 1)
                }
            }
            "books" -> {
                val n = i.getIntExtra("n", 0)
                if (n == 0) Scheduler.scheduleNight(c) // line up tomorrow's reminder
                Notifier.books(c, Store.tomorrowText(c), n)
                if (n < Scheduler.MAX_BOOKS_REPEATS) {
                    Scheduler.repeatBooks(c, n + 1)
                }
            }
        }
    }
}
