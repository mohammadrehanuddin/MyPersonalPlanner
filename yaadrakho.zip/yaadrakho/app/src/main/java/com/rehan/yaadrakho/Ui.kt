package com.rehan.yaadrakho

import android.content.Context
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView

object Ui {
    val RED_BG = Color.parseColor("#FCEBEB")
    val RED_LINE = Color.parseColor("#F09595")
    val RED_TX = Color.parseColor("#791F1F")
    val YEL_BG = Color.parseColor("#FAEEDA")
    val YEL_LINE = Color.parseColor("#EF9F27")
    val YEL_TX = Color.parseColor("#633806")
    val GRN_BG = Color.parseColor("#EAF3DE")
    val GRN_LINE = Color.parseColor("#97C459")
    val GRN_TX = Color.parseColor("#27500A")
    val WHT_BG = Color.WHITE
    val WHT_LINE = Color.parseColor("#B4B2A9")
    val WHT_TX = Color.parseColor("#2C2C2A")
    val GRY_BG = Color.parseColor("#F1EFE8")
    val GRY_LINE = Color.parseColor("#D3D1C7")
    val GRY_TX = Color.parseColor("#888780")
    val BLUE = Color.parseColor("#185FA5")
    val BLUE_BG = Color.parseColor("#E6F1FB")
    val MUTED = Color.parseColor("#5F5E5A")

    fun dp(c: Context, v: Int): Int = (v * c.resources.displayMetrics.density).toInt()

    fun box(c: Context, fill: Int, line: Int): GradientDrawable {
        val g = GradientDrawable()
        g.setColor(fill)
        g.cornerRadius = dp(c, 8).toFloat()
        g.setStroke(dp(c, 1), line)
        return g
    }

    // returns [background, border, text]
    fun colors(kind: String): IntArray = when (kind) {
        "red" -> intArrayOf(RED_BG, RED_LINE, RED_TX)
        "yellow" -> intArrayOf(YEL_BG, YEL_LINE, YEL_TX)
        "free" -> intArrayOf(GRN_BG, GRN_LINE, GRN_TX)
        "done" -> intArrayOf(GRY_BG, GRY_LINE, GRY_TX)
        "break" -> intArrayOf(WHT_BG, WHT_LINE, MUTED)
        else -> intArrayOf(WHT_BG, WHT_LINE, WHT_TX)
    }

    fun text(c: Context, s: String, size: Float, bold: Boolean, color: Int): TextView {
        val t = TextView(c)
        t.text = s
        t.textSize = size
        t.setTextColor(color)
        if (bold) t.setTypeface(t.typeface, Typeface.BOLD)
        return t
    }

    fun block(c: Context, kind: String, title: String, sub: String): LinearLayout {
        val col = colors(kind)
        val l = LinearLayout(c)
        l.orientation = LinearLayout.VERTICAL
        l.background = box(c, col[0], col[1])
        l.setPadding(dp(c, 10), dp(c, 6), dp(c, 10), dp(c, 6))
        val t = text(c, title, 15f, false, col[2])
        if (kind == "done") t.paintFlags = t.paintFlags or Paint.STRIKE_THRU_TEXT_FLAG
        l.addView(t)
        if (sub.isNotEmpty()) l.addView(text(c, sub, 12f, false, col[2]))
        return l
    }

    fun params(c: Context, topDp: Int): LinearLayout.LayoutParams {
        val p = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        )
        p.topMargin = dp(c, topDp)
        return p
    }

    fun add(parent: LinearLayout, v: View, topDp: Int) {
        parent.addView(v, params(parent.context, topDp))
    }
}
