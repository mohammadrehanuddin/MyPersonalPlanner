package com.rehan.yaadrakho

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.RingtoneManager

object Notifier {
    private const val CHANNEL = "yaad_alarm"
    const val BOOKS_NOTIF = 1001
    private const val FLAGS = PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE

    fun ensureChannel(c: Context) {
        val nm = c.getSystemService(NotificationManager::class.java)
        if (nm.getNotificationChannel(CHANNEL) != null) return
        val ch = NotificationChannel(CHANNEL, "Reminders", NotificationManager.IMPORTANCE_HIGH)
        ch.description = "Task and books reminders"
        ch.enableVibration(true)
        ch.vibrationPattern = longArrayOf(0, 500, 300, 500)
        val attrs = AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_ALARM)
            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
            .build()
        ch.setSound(RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM), attrs)
        nm.createNotificationChannel(ch)
    }

    private fun action(c: Context, act: String, kind: String, id: Long, label: String): Notification.Action {
        val i = Intent(c, ActionReceiver::class.java)
            .setAction(act)
            .putExtra("kind", kind)
            .putExtra("id", id)
        val pi = PendingIntent.getBroadcast(c, Scheduler.rc(id), i, FLAGS)
        return Notification.Action.Builder(0, label, pi).build()
    }

    private fun openApp(c: Context): PendingIntent =
        PendingIntent.getActivity(c, 0, Intent(c, MainActivity::class.java), FLAGS)

    fun task(c: Context, t: Task, n: Int) {
        ensureChannel(c)
        val text = if (n == 0) "Abhi karne ka time hai" else "Abhi tak done nahi kiya (reminder ${n + 1})"
        val b = Notification.Builder(c, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_popup_reminder)
            .setContentTitle("Yaad karo: ${t.title}")
            .setContentText(text)
            .setContentIntent(openApp(c))
            .setCategory(Notification.CATEGORY_REMINDER)
            .setAutoCancel(false)
            .addAction(action(c, "DONE", "task", t.id, "Done"))
            .addAction(action(c, "SNOOZE", "task", t.id, "10 min baad"))
        c.getSystemService(NotificationManager::class.java).notify(Scheduler.rc(t.id), b.build())
    }

    fun books(c: Context, text: String, n: Int) {
        ensureChannel(c)
        val title = if (n == 0) "Kal ki books bag mein rakho" else "Books rakhi? (reminder ${n + 1})"
        val b = Notification.Builder(c, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_popup_reminder)
            .setContentTitle(title)
            .setContentText(text)
            .setStyle(Notification.BigTextStyle().bigText(text))
            .setContentIntent(openApp(c))
            .setCategory(Notification.CATEGORY_REMINDER)
            .setAutoCancel(false)
            .addAction(action(c, "DONE", "books", -1L, "Rakh di"))
        c.getSystemService(NotificationManager::class.java).notify(BOOKS_NOTIF, b.build())
    }
}
