package com.rehan.yaadrakho

import android.app.Activity
import android.app.NotificationManager
import android.content.Intent
import android.graphics.Typeface
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object Screens {
    private val dayFmt = SimpleDateFormat("EEE, d MMM", Locale.ENGLISH)
    private val rowFmt = SimpleDateFormat("d MMM, h:mm a", Locale.ENGLISH)
    private val endFmt = SimpleDateFormat("h:mm a", Locale.ENGLISH)
    private val dayNames = listOf("Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun")

    // Schedule tab state
    private var selected: Long = Logic.startOfDay(System.currentTimeMillis())
    private var weekStart: Long = Logic.mondayOf(System.currentTimeMillis())

    private fun page(a: Activity, build: (LinearLayout) -> Unit): ScrollView {
        val col = LinearLayout(a)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(Ui.dp(a, 16), Ui.dp(a, 20), Ui.dp(a, 16), Ui.dp(a, 16))
        build(col)
        val sv = ScrollView(a)
        sv.addView(col)
        return sv
    }

    private fun heading(a: Activity, s: String): TextView =
        Ui.text(a, s, 18f, true, Ui.WHT_TX)

    private fun note(a: Activity, s: String): TextView =
        Ui.text(a, s, 13f, false, Ui.MUTED)

    private fun cancelAlarm(a: Activity, t: Task) {
        Scheduler.cancelTask(a, t.id)
        a.getSystemService(NotificationManager::class.java).cancel(Scheduler.rc(t.id))
    }

    private fun taskRow(a: Activity, t: Task, refresh: () -> Unit): LinearLayout {
        val st = Logic.status(t)
        val kind = when (st.level) {
            Level.RED -> "red"
            Level.YELLOW -> "yellow"
            Level.DONE -> "done"
        }
        val detail = t.category + " · " + rowFmt.format(Date(t.whenMs)) + " to " +
            endFmt.format(Date(t.endMs)) + "\n" + st.text
        val b = Ui.block(a, kind, t.title, detail)

        val btns = LinearLayout(a)
        btns.orientation = LinearLayout.HORIZONTAL
        if (!t.done) {
            val done = Button(a)
            done.text = "Done"
            done.setOnClickListener {
                Store.markDone(a, t.id)
                cancelAlarm(a, t)
                refresh()
            }
            btns.addView(done)
        }
        val del = Button(a)
        del.text = "Delete"
        del.setOnClickListener {
            cancelAlarm(a, t)
            Store.remove(a, t.id)
            refresh()
        }
        btns.addView(del)
        b.addView(btns)
        return b
    }

    // ---------------- Today ----------------

    fun today(a: Activity, refresh: () -> Unit): View = page(a) { col ->
        col.addView(Ui.text(a, "Today", 28f, true, Ui.WHT_TX))
        col.addView(note(a, dayFmt.format(Date())))

        Ui.add(col, Ui.block(a, "class", "Tomorrow's books", Store.tomorrowText(a)), 12)

        val now = System.currentTimeMillis()
        val dayStart = Logic.startOfDay(now)
        val dayEnd = Logic.addDays(dayStart, 1)
        val all = Store.tasks(a)
        val todays = all.filter { it.whenMs >= dayStart && it.whenMs < dayEnd }.sortedBy { it.whenMs }

        Ui.add(col, heading(a, "Planned for today"), 20)
        if (todays.isEmpty()) {
            Ui.add(col, note(a, "Nothing planned. Add a task from the Tasks tab."), 6)
        }
        for (t in todays) Ui.add(col, taskRow(a, t, refresh), 8)

        val urgent = all.filter {
            !it.done && Logic.status(it).level == Level.RED &&
                !(it.whenMs >= dayStart && it.whenMs < dayEnd)
        }.sortedBy { it.deadlineMs }
        if (urgent.isNotEmpty()) {
            Ui.add(col, heading(a, "Needs attention"), 20)
            for (t in urgent) Ui.add(col, taskRow(a, t, refresh), 8)
        }
    }

    // ---------------- Schedule ----------------

    fun schedule(a: Activity, refresh: () -> Unit): View = page(a) { col ->
        col.addView(Ui.text(a, "Schedule", 28f, true, Ui.WHT_TX))
        col.addView(note(a, "White: class   Red: must do   Yellow: can wait   Green: free"))

        val nav = LinearLayout(a)
        nav.orientation = LinearLayout.HORIZONTAL
        val prev = Button(a)
        prev.text = "< Week"
        prev.setOnClickListener {
            weekStart = Logic.addDays(weekStart, -7)
            selected = weekStart
            refresh()
        }
        val next = Button(a)
        next.text = "Week >"
        next.setOnClickListener {
            weekStart = Logic.addDays(weekStart, 7)
            selected = weekStart
            refresh()
        }
        val todayBtn = Button(a)
        todayBtn.text = "Today"
        todayBtn.setOnClickListener {
            selected = Logic.startOfDay(System.currentTimeMillis())
            weekStart = Logic.mondayOf(selected)
            refresh()
        }
        val w = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        nav.addView(prev, w)
        nav.addView(todayBtn, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        nav.addView(next, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        Ui.add(col, nav, 8)

        val strip = LinearLayout(a)
        strip.orientation = LinearLayout.HORIZONTAL
        val dnum = SimpleDateFormat("d", Locale.ENGLISH)
        for (i in 0 until 7) {
            val day = Logic.addDays(weekStart, i)
            val b = Button(a)
            b.text = dayNames[i] + "\n" + dnum.format(Date(day))
            b.textSize = 12f
            b.minWidth = 0
            b.minimumWidth = 0
            b.setPadding(0, 0, 0, 0)
            if (Logic.startOfDay(day) == selected) {
                b.background = Ui.box(a, Ui.BLUE_BG, Ui.BLUE)
                b.setTextColor(Ui.BLUE)
            }
            b.setOnClickListener {
                selected = Logic.startOfDay(day)
                refresh()
            }
            strip.addView(b, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        }
        Ui.add(col, strip, 4)

        Ui.add(col, heading(a, dayFmt.format(Date(selected))), 12)

        if (Store.slots(a).isEmpty()) {
            Ui.add(
                col,
                Ui.block(
                    a, "yellow", "Set up your timetable",
                    "Add your period timings and subjects once. Free time and class blocks appear after that."
                ),
                8
            )
        }

        val blocks = Logic.blocksFor(a, selected)
        for (b in blocks) {
            val row = LinearLayout(a)
            row.orientation = LinearLayout.HORIZONTAL
            val time = Ui.text(a, Logic.fmt(b.s), 11f, false, Ui.GRY_TX)
            row.addView(time, LinearLayout.LayoutParams(Ui.dp(a, 62), LinearLayout.LayoutParams.WRAP_CONTENT))
            row.addView(
                Ui.block(a, b.kind, b.title, b.sub),
                LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            )
            Ui.add(col, row, 6)
        }

        val edit = Button(a)
        edit.text = "Edit timetable"
        edit.setOnClickListener { a.startActivity(Intent(a, TimetableActivity::class.java)) }
        Ui.add(col, edit, 16)
    }

    // ---------------- Tasks ----------------

    fun tasks(a: Activity, refresh: () -> Unit): View = page(a) { col ->
        col.addView(Ui.text(a, "Tasks", 28f, true, Ui.WHT_TX))

        val add = Button(a)
        add.text = "Add task"
        add.setOnClickListener { a.startActivity(Intent(a, AddTaskActivity::class.java)) }
        Ui.add(col, add, 8)

        val list = Store.tasks(a).sortedWith(
            compareBy<Task>(
                { it.done },
                { Logic.status(it).level != Level.RED },
                { it.deadlineMs }
            )
        )
        if (list.isEmpty()) {
            Ui.add(col, note(a, "No tasks yet. Add your first one."), 12)
        }
        for (t in list) Ui.add(col, taskRow(a, t, refresh), 8)
    }
}
