package com.rehan.yaadrakho

import android.app.Activity
import android.app.AlertDialog
import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.os.Bundle
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

class AddTaskActivity : Activity() {

    private lateinit var titleInput: EditText
    private lateinit var needInput: EditText
    private lateinit var deadlineBtn: Button
    private lateinit var dayBtn: Button
    private lateinit var startBtn: Button
    private lateinit var endBtn: Button
    private lateinit var info: LinearLayout
    private val catButtons = mutableListOf<Button>()

    private var category = Cat.HOMEWORK

    private val deadline: Calendar = Calendar.getInstance()
    private val day: Calendar = Calendar.getInstance()
    private val start: Calendar = Calendar.getInstance()
    private val end: Calendar = Calendar.getInstance()

    private val dateFmt = SimpleDateFormat("EEE, d MMM", Locale.ENGLISH)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        deadline.add(Calendar.DAY_OF_YEAR, 2)
        start.add(Calendar.HOUR_OF_DAY, 1)
        start.set(Calendar.MINUTE, 0)
        end.timeInMillis = start.timeInMillis
        end.add(Calendar.HOUR_OF_DAY, 1)
        day.timeInMillis = start.timeInMillis

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(Ui.dp(this, 16), Ui.dp(this, 20), Ui.dp(this, 16), Ui.dp(this, 16))

        root.addView(Ui.text(this, "Add task", 28f, true, Ui.WHT_TX))

        root.addView(label("Task"))
        titleInput = EditText(this)
        titleInput.hint = "e.g. ODE homework"
        root.addView(titleInput)

        root.addView(label("Category"))
        val row1 = LinearLayout(this)
        row1.orientation = LinearLayout.HORIZONTAL
        val row2 = LinearLayout(this)
        row2.orientation = LinearLayout.HORIZONTAL
        for (i in Cat.all.indices) {
            val name = Cat.all[i]
            val b = Button(this)
            b.text = name
            b.setOnClickListener {
                category = name
                needInput.setText(Cat.defaultNeed(name).toString())
                paintCats()
                updateInfo()
            }
            catButtons.add(b)
            val lp = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            if (i < 2) row1.addView(b, lp) else row2.addView(b, lp)
        }
        root.addView(row1)
        root.addView(row2)

        root.addView(label("Deadline"))
        deadlineBtn = Button(this)
        deadlineBtn.setOnClickListener { pickDate(deadline) { updateButtons(); updateInfo() } }
        root.addView(deadlineBtn)

        root.addView(label("Time needed (days)"))
        needInput = EditText(this)
        needInput.inputType = InputType.TYPE_CLASS_NUMBER
        needInput.setText(Cat.defaultNeed(category).toString())
        needInput.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) {
                updateInfo()
            }
        })
        root.addView(needInput)

        root.addView(label("When will you do it"))
        dayBtn = Button(this)
        dayBtn.setOnClickListener { pickDate(day) { updateButtons() } }
        root.addView(dayBtn)
        val times = LinearLayout(this)
        times.orientation = LinearLayout.HORIZONTAL
        startBtn = Button(this)
        startBtn.setOnClickListener { pickTime(start) { updateButtons() } }
        endBtn = Button(this)
        endBtn.setOnClickListener { pickTime(end) { updateButtons() } }
        times.addView(startBtn, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        times.addView(endBtn, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        root.addView(times)

        info = LinearLayout(this)
        info.orientation = LinearLayout.VERTICAL
        Ui.add(root, info, 12)

        val add = Button(this)
        add.text = "Add task"
        add.setOnClickListener { tryAdd() }
        Ui.add(root, add, 12)

        val sv = ScrollView(this)
        sv.addView(root)
        setContentView(sv)

        paintCats()
        updateButtons()
        updateInfo()
    }

    private fun label(s: String): TextView {
        val t = Ui.text(this, s, 13f, false, Ui.MUTED)
        t.setPadding(0, Ui.dp(this, 12), 0, 0)
        return t
    }

    private fun paintCats() {
        for (i in catButtons.indices) {
            val on = Cat.all[i] == category
            catButtons[i].setTextColor(if (on) Ui.BLUE else Ui.MUTED)
            if (on) catButtons[i].background = Ui.box(this, Ui.BLUE_BG, Ui.BLUE)
            else catButtons[i].background = Ui.box(this, Ui.WHT_BG, Ui.GRY_LINE)
        }
    }

    private fun timeText(c: Calendar): String =
        Logic.fmt(c.get(Calendar.HOUR_OF_DAY) * 60 + c.get(Calendar.MINUTE))

    private fun updateButtons() {
        deadlineBtn.text = dateFmt.format(deadline.time)
        dayBtn.text = dateFmt.format(day.time)
        startBtn.text = "Start " + timeText(start)
        endBtn.text = "End " + timeText(end)
    }

    private fun pickDate(c: Calendar, done: () -> Unit) {
        DatePickerDialog(
            this,
            DatePickerDialog.OnDateSetListener { _, y, m, d ->
                c.set(y, m, d)
                done()
            },
            c.get(Calendar.YEAR),
            c.get(Calendar.MONTH),
            c.get(Calendar.DAY_OF_MONTH)
        ).show()
    }

    private fun pickTime(c: Calendar, done: () -> Unit) {
        TimePickerDialog(
            this,
            TimePickerDialog.OnTimeSetListener { _, h, m ->
                c.set(Calendar.HOUR_OF_DAY, h)
                c.set(Calendar.MINUTE, m)
                done()
            },
            c.get(Calendar.HOUR_OF_DAY),
            c.get(Calendar.MINUTE),
            false
        ).show()
    }

    private fun needDays(): Int {
        val n = needInput.text.toString().trim().toIntOrNull()
        return if (n == null || n < 0) Cat.defaultNeed(category) else n
    }

    private fun slotMs(t: Calendar): Long {
        val c = Calendar.getInstance()
        c.timeInMillis = day.timeInMillis
        c.set(Calendar.HOUR_OF_DAY, t.get(Calendar.HOUR_OF_DAY))
        c.set(Calendar.MINUTE, t.get(Calendar.MINUTE))
        c.set(Calendar.SECOND, 0)
        c.set(Calendar.MILLISECOND, 0)
        return c.timeInMillis
    }

    private fun buildTask(title: String): Task {
        val s = slotMs(start)
        val e = slotMs(end)
        return Task(
            id = System.currentTimeMillis(),
            title = title,
            whenMs = s,
            done = false,
            category = category,
            endMs = e,
            deadlineMs = Logic.startOfDay(deadline.timeInMillis),
            needDays = needDays()
        )
    }

    private fun updateInfo() {
        if (!::info.isInitialized) return
        info.removeAllViews()
        val st = Logic.status(buildTask("preview"))
        val kind = if (st.level == Level.RED) "red" else "yellow"
        val head = if (st.level == Level.RED) "Color today: red" else "Color today: yellow"
        info.addView(Ui.block(this, kind, head, st.text))
    }

    private fun tryAdd() {
        val title = titleInput.text.toString().trim()
        if (title.isEmpty()) {
            Toast.makeText(this, "Enter a task name first", Toast.LENGTH_SHORT).show()
            return
        }
        val s = slotMs(start)
        val e = slotMs(end)
        if (e <= s) {
            Toast.makeText(this, "End time must be after start time", Toast.LENGTH_SHORT).show()
            return
        }
        if (s <= System.currentTimeMillis()) {
            Toast.makeText(this, "Pick a start time in the future", Toast.LENGTH_SHORT).show()
            return
        }
        val clashes = Logic.conflicts(this, s, e)
        if (clashes.isEmpty()) {
            save(title)
        } else {
            AlertDialog.Builder(this)
                .setTitle("That slot is already taken")
                .setMessage(clashes.joinToString("\n") + "\n\nAdd anyway?")
                .setPositiveButton("Add anyway") { _, _ -> save(title) }
                .setNegativeButton("Pick another time", null)
                .show()
        }
    }

    private fun save(title: String) {
        val t = buildTask(title)
        Store.add(this, t)
        Scheduler.scheduleTask(this, t)
        Toast.makeText(this, "Task added", Toast.LENGTH_SHORT).show()
        finish()
    }
}
