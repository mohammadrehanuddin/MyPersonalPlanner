package com.rehan.yaadrakho

data class Task(
    val id: Long,
    val title: String,
    val whenMs: Long,
    var done: Boolean = false,
    val category: String = Cat.HOMEWORK,
    val endMs: Long = whenMs + 3_600_000L,
    val deadlineMs: Long = whenMs,
    val needDays: Int = 1
)

object Cat {
    const val HOMEWORK = "Homework"
    const val EXAM = "Exam prep"
    const val READING = "Reading"
    const val ANIMATION = "Animation"

    val all = listOf(HOMEWORK, EXAM, READING, ANIMATION)

    fun defaultNeed(c: String): Int = when (c) {
        EXAM -> 3
        READING -> 2
        else -> 1
    }
}

// One period in the day. subj maps Calendar.DAY_OF_WEEK to the subject for that day.
data class Slot(
    var s: Int,
    var e: Int,
    var brk: Boolean,
    val subj: MutableMap<Int, String> = mutableMapOf()
)

enum class Level { RED, YELLOW, DONE }

data class Status(val level: Level, val text: String)

data class Block(
    val s: Int,
    val e: Int,
    val kind: String,
    val title: String,
    val sub: String
)
