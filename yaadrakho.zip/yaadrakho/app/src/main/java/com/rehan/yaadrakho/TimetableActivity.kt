package com.rehan.yaadrakho

import android.app.Activity
import android.app.TimePickerDialog
import android.graphics.Typeface
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.util.Calendar

class TimetableActivity : Activity() {

    private val days = listOf(
        Calendar.MONDAY to "Monday",
        Calendar.TUESDAY to "Tuesday",
        Calendar.WEDNESDAY to "Wednesday",
        Calendar.THURSDAY to "Thursday",
        Calendar.FRIDAY to "Friday",
        Calendar.SATURDAY to "Saturday"
    )
    private val inputs = mutableMapOf<Int, EditText>()
    private lateinit var nightBtn: Button
    private var hour = 21
    private var minute = 0

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        hour = Store.nightHour(this)
        minute = Store.nightMinute(this)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(24), dp(16), dp(24))
        }
        setContentView(ScrollView(this).apply { addView(root) })

        root.addView(TextView(this).apply {
            text = "Timetable"
            textSize = 28f
            setTypeface(typeface, Typeface.BOLD)
        })
        root.addView(TextView(this).apply {
            text = "Har din ke periods comma se likho, us order mein jis mein books chahiye.\n" +
                "Subjects: ODE, EC, ESE, PPS, EDC\n" +
                "Labs: EC Lab, ELCS Lab, PPS Lab, PYT Lab, ISI Lab"
            setPadding(0, dp(8), 0, dp(8))
        })

        for ((day, name) in days) {
            root.addView(TextView(this).apply {
                text = name
                textSize = 16f
                setTypeface(typeface, Typeface.BOLD)
                setPadding(0, dp(12), 0, 0)
            })
            val et = EditText(this).apply {
                hint = "jaise: ODE, EC, PPS Lab"
                setText(Store.periods(this@TimetableActivity, day))
            }
            inputs[day] = et
            root.addView(et)
        }

        root.addView(TextView(this).apply {
            text = "Raat ka reminder kis time pe aaye?"
            setPadding(0, dp(20), 0, 0)
        })
        nightBtn = Button(this).apply { setOnClickListener { pickNight() } }
        root.addView(nightBtn)
        updateNightBtn()

        root.addView(Button(this).apply {
            text = "Save"
            setOnClickListener { save() }
        })
    }

    private fun updateNightBtn() {
        nightBtn.text = String.format("%02d:%02d", hour, minute)
    }

    private fun pickNight() {
        TimePickerDialog(
            this,
            TimePickerDialog.OnTimeSetListener { _, h, m ->
                hour = h
                minute = m
                updateNightBtn()
            },
            hour,
            minute,
            true
        ).show()
    }

    private fun save() {
        for ((day, et) in inputs) {
            Store.setPeriods(this, day, et.text.toString())
        }
        Store.setNight(this, hour, minute)
        Scheduler.scheduleNight(this)
        Toast.makeText(this, "Save ho gaya", Toast.LENGTH_SHORT).show()
        finish()
    }
}
