package com.rehan.yaadrakho

import android.app.Activity
import android.app.TimePickerDialog
import android.os.Bundle
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.util.Calendar

class TimetableActivity : Activity() {

    private val days = listOf(
        Calendar.MONDAY to "Mon",
        Calendar.TUESDAY to "Tue",
        Calendar.WEDNESDAY to "Wed",
        Calendar.THURSDAY to "Thu",
        Calendar.FRIDAY to "Fri",
        Calendar.SATURDAY to "Sat",
        Calendar.SUNDAY to "Sun"
    )

    private lateinit var root: LinearLayout
    private lateinit var slots: MutableList<Slot>
    private val fields = mutableListOf<Pair<Slot, EditText>>()
    private var selectedDow = Calendar.MONDAY
    private var winStart = 7 * 60
    private var winEnd = 22 * 60
    private var nightH = 21
    private var nightM = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        slots = Store.slots(this)
        winStart = Store.windowStart(this)
        winEnd = Store.windowEnd(this)
        nightH = Store.nightHour(this)
        nightM = Store.nightMinute(this)

        root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(Ui.dp(this, 16), Ui.dp(this, 20), Ui.dp(this, 16), Ui.dp(this, 24))
        val sv = ScrollView(this)
        sv.addView(root)
        setContentView(sv)
        rebuild()
    }

    // Copy what is typed in the subject boxes back into the slots.
    private fun capture() {
        for ((sl, et) in fields) {
            val v = et.text.toString().trim()
            if (v.isEmpty()) sl.subj.remove(selectedDow) else sl.subj[selectedDow] = v
        }
    }

    private fun rebuild() {
        root.removeAllViews()
        fields.clear()

        root.addView(Ui.text(this, "Timetable", 28f, true, Ui.WHT_TX))
        Ui.add(
            root,
            Ui.text(
                this,
                "Step 1: add your periods once (start and end time). " +
                    "Step 2: pick a day and type the subject for each period.",
                13f, false, Ui.MUTED
            ),
            4
        )

        Ui.add(root, Ui.text(this, "Periods", 18f, true, Ui.WHT_TX), 16)
        for (i in slots.indices) {
            val sl = slots[i]
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL

            val num = Ui.text(this, (i + 1).toString() + ".", 15f, false, Ui.WHT_TX)
            row.addView(num, LinearLayout.LayoutParams(Ui.dp(this, 24), LinearLayout.LayoutParams.WRAP_CONTENT))

            val sb = Button(this)
            sb.text = Logic.fmt(sl.s)
            sb.setOnClickListener {
                pickTime(sl.s) { m ->
                    capture()
                    sl.s = m
                    rebuild()
                }
            }
            row.addView(sb, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))

            val eb = Button(this)
            eb.text = Logic.fmt(sl.e)
            eb.setOnClickListener {
                pickTime(sl.e) { m ->
                    capture()
                    sl.e = m
                    rebuild()
                }
            }
            row.addView(eb, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))

            val cb = CheckBox(this)
            cb.text = "Break"
            cb.isChecked = sl.brk
            cb.setOnCheckedChangeListener { _, checked ->
                capture()
                sl.brk = checked
                rebuild()
            }
            row.addView(cb)

            val del = Button(this)
            del.text = "X"
            del.setOnClickListener {
                capture()
                slots.remove(sl)
                rebuild()
            }
            row.addView(del)
            Ui.add(root, row, 2)
        }

        val addSlot = Button(this)
        addSlot.text = "Add period"
        addSlot.setOnClickListener {
            capture()
            val last = slots.lastOrNull()
            val s = if (last != null) last.e else 9 * 60
            slots.add(Slot(s, minOf(s + 50, 1439), false))
            rebuild()
        }
        Ui.add(root, addSlot, 6)

        Ui.add(root, Ui.text(this, "Subjects", 18f, true, Ui.WHT_TX), 20)
        val strip = LinearLayout(this)
        strip.orientation = LinearLayout.HORIZONTAL
        for ((dow, name) in days) {
            val b = Button(this)
            b.text = name
            b.textSize = 12f
            b.minWidth = 0
            b.minimumWidth = 0
            b.setPadding(0, 0, 0, 0)
            if (dow == selectedDow) {
                b.background = Ui.box(this, Ui.BLUE_BG, Ui.BLUE)
                b.setTextColor(Ui.BLUE)
            }
            b.setOnClickListener {
                capture()
                selectedDow = dow
                rebuild()
            }
            strip.addView(b, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        }
        Ui.add(root, strip, 6)

        var shown = 0
        for (sl in slots) {
            if (sl.brk) continue
            shown++
            val label = Ui.text(this, Logic.range(sl.s, sl.e), 12f, false, Ui.MUTED)
            Ui.add(root, label, 8)
            val et = EditText(this)
            et.hint = "Subject, e.g. ODE or PPS Lab"
            et.setText(sl.subj[selectedDow] ?: "")
            root.addView(et)
            fields.add(Pair(sl, et))
        }
        if (shown == 0) {
            Ui.add(root, Ui.text(this, "Add periods above to enter subjects.", 13f, false, Ui.MUTED), 8)
        }

        Ui.add(root, Ui.text(this, "Free time window", 18f, true, Ui.WHT_TX), 20)
        Ui.add(root, Ui.text(this, "Free time is shown between these two times.", 13f, false, Ui.MUTED), 2)
        val win = LinearLayout(this)
        win.orientation = LinearLayout.HORIZONTAL
        val ws = Button(this)
        ws.text = "From " + Logic.fmt(winStart)
        ws.setOnClickListener {
            pickTime(winStart) { m ->
                capture()
                winStart = m
                rebuild()
            }
        }
        val we = Button(this)
        we.text = "To " + Logic.fmt(winEnd)
        we.setOnClickListener {
            pickTime(winEnd) { m ->
                capture()
                winEnd = m
                rebuild()
            }
        }
        win.addView(ws, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        win.addView(we, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        root.addView(win)

        Ui.add(root, Ui.text(this, "Nightly books reminder", 18f, true, Ui.WHT_TX), 20)
        val nb = Button(this)
        nb.text = Logic.fmt(nightH * 60 + nightM)
        nb.setOnClickListener {
            pickTime(nightH * 60 + nightM) { m ->
                capture()
                nightH = m / 60
                nightM = m % 60
                rebuild()
            }
        }
        root.addView(nb)

        val save = Button(this)
        save.text = "Save"
        save.setOnClickListener { save() }
        Ui.add(root, save, 20)
    }

    private fun pickTime(current: Int, done: (Int) -> Unit) {
        TimePickerDialog(
            this,
            TimePickerDialog.OnTimeSetListener { _, h, m -> done(h * 60 + m) },
            current / 60,
            current % 60,
            false
        ).show()
    }

    private fun save() {
        capture()
        for (sl in slots) {
            if (sl.e <= sl.s) {
                Toast.makeText(this, "Each period must end after it starts", Toast.LENGTH_SHORT).show()
                return
            }
        }
        if (winEnd <= winStart) {
            Toast.makeText(this, "Free time window must end after it starts", Toast.LENGTH_SHORT).show()
            return
        }
        slots.sortBy { it.s }
        Store.saveSlots(this, slots)
        Store.setWindow(this, winStart, winEnd)
        Store.setNight(this, nightH, nightM)
        Scheduler.scheduleNight(this)
        Toast.makeText(this, "Saved", Toast.LENGTH_SHORT).show()
        finish()
    }
}
