package com.rehan.yaadrakho

import android.app.Application
import android.content.Context
import java.io.PrintWriter
import java.io.StringWriter

// Saves any crash so MainActivity can show it on the next launch.
class App : Application() {
    override fun onCreate() {
        super.onCreate()
        val old = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread, e ->
            try {
                val sw = StringWriter()
                e.printStackTrace(PrintWriter(sw))
                getSharedPreferences("crash", Context.MODE_PRIVATE)
                    .edit().putString("trace", sw.toString()).commit()
            } catch (_: Throwable) {
            }
            old?.uncaughtException(thread, e)
        }
    }
}
