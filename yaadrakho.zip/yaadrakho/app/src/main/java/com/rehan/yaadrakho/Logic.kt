package com.rehan.yaadrakho

import android.content.Context
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

object Logic {
    private const val DAY_MS = 86_400_000L

    fun startOfDay(ms: Long): Long {
        val c = Calendar.getInstance()
        c.timeInMillis = ms
        c.set(Calendar.HOUR_OF_DAY, 0)
        c.set(Calendar.MINUTE, 0)
        c.set(Calendar.SECOND, 0)
        c.set(Calendar.MILLISECOND, 0)
        return c.timeInMillis
    }

    fun addDays(ms: Long, days: Int): Long {
        val c = Calendar.getInstance()
        c.timeInMillis = ms
        c.add(Calendar.DAY_OF_YEAR, days)
        return c.timeInMillis
    }

    fun mondayOf(ms: Long): Long {
        val c = Calendar.getInstance()
        c.timeInMillis = startOfDay(ms)
        val dow = c.get(Calendar.DAY_OF_WEEK)
        val back = (dow + 5) % 7 // Monday = 0 ... Sunday = 6
        c.add(Calendar.DAY_OF_YEAR, -back)
        return c.timeInMillis
    }

    fun daysBetween(fromMs: Long, toMs: Long): Int {
        val a = startOfDay(fromMs)
        val b = startOfDay(toMs)
        return Math.round((b - a).toDouble() / DAY_MS).toInt()
    }

    fun fmt(min: Int): String {
        val h = min / 60
        val m = min % 60
        val h12 = if (h % 12 == 0) 12 else h % 12
        val ap = if (h < 12) "AM" else "PM"
        return String.format(Locale.ENGLISH, "%d:%02d %s", h12, m, ap)
    }

    fun range(s: Int, e: Int): String = fmt(s) + " to " + fmt(e)

    // Yellow while there is spare time; red once days left <= days needed.
    fun status(t: Task, now: Long = System.currentTimeMillis()): Status {
        if (t.done) return Status(Level.DONE, "Done")
        val left = daysBetween(now, t.deadlineMs)
        val flexible = t.category == Cat.ANIMATION
        if (left < 0) {
            return if (flexible) Status(Level.YELLOW, "Overdue, flexible")
            else Status(Level.RED, "Overdue")
        }
        val due = when (left) {
            0 -> "Due today"
            1 -> "Due tomorrow"
            else -> "Due in $left days"
        }
        if (flexible) return Status(Level.YELLOW, "$due, flexible")
        if (left <= t.needDays) {
            return Status(Level.RED, due + ", needs " + t.needDays + "d")
        }
        val redOn = addDays(t.deadlineMs, -t.needDays)
        val f = SimpleDateFormat("EEE d MMM", Locale.ENGLISH)
        return Status(
            Level.YELLOW,
            due + ", needs " + t.needDays + "d. Turns red " + f.format(Date(redOn))
        )
    }

    private fun minutesOf(ms: Long, dayStart: Long): Int {
        val m = ((ms - dayStart) / 60_000L).toInt()
        return if (m < 0) 0 else if (m > 1440) 1440 else m
    }

    // Everything shown for one day: classes, breaks, planned tasks and free gaps.
    fun blocksFor(c: Context, dayMs: Long): List<Block> {
        val dayStart = startOfDay(dayMs)
        val dayEnd = addDays(dayStart, 1)
        val cal = Calendar.getInstance()
        cal.timeInMillis = dayStart
        val dow = cal.get(Calendar.DAY_OF_WEEK)

        val out = mutableListOf<Block>()
        for (sl in Store.slots(c)) {
            if (sl.brk) {
                out.add(Block(sl.s, sl.e, "break", "Break", range(sl.s, sl.e)))
            } else {
                val name = sl.subj[dow]
                if (name != null && name.isNotBlank()) {
                    out.add(Block(sl.s, sl.e, "class", name, range(sl.s, sl.e)))
                }
            }
        }
        for (t in Store.tasks(c)) {
            if (t.whenMs < dayStart || t.whenMs >= dayEnd) continue
            val st = minutesOf(t.whenMs, dayStart)
            var en = minutesOf(t.endMs, dayStart)
            if (en < st + 15) en = st + 15
            if (en > 1440) en = 1440
            val s = status(t)
            val kind = when (s.level) {
                Level.RED -> "red"
                Level.YELLOW -> "yellow"
                Level.DONE -> "done"
            }
            out.add(Block(st, en, kind, t.title, range(st, en) + " · " + s.text))
        }

        val busy = out.filter { it.kind != "done" }.sortedBy { it.s }
        val ws = Store.windowStart(c)
        val we = Store.windowEnd(c)
        var cursor = ws
        for (b in busy) {
            if (b.s - cursor >= 15) {
                out.add(Block(cursor, b.s, "free", "Free time", range(cursor, b.s)))
            }
            if (b.e > cursor) cursor = b.e
        }
        if (we - cursor >= 15) {
            out.add(Block(cursor, we, "free", "Free time", range(cursor, we)))
        }
        return out.sortedWith(compareBy<Block>({ it.s }, { it.e }))
    }

    // Red tasks and classes that overlap a proposed slot.
    fun conflicts(c: Context, startMs: Long, endMs: Long): List<String> {
        val dayStart = startOfDay(startMs)
        val s = minutesOf(startMs, dayStart)
        var e = minutesOf(endMs, dayStart)
        if (e <= s) e = s + 1
        return blocksFor(c, startMs)
            .filter { (it.kind == "red" || it.kind == "class") && it.s < e && s < it.e }
            .map {
                val label = if (it.kind == "red") "Red task" else "Class"
                label + ": " + it.title + " (" + range(it.s, it.e) + ")"
            }
    }
}
