package com.rehan.yaadrakho

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

data class Task(val id: Long, val title: String, val whenMs: Long, var done: Boolean = false)

object Store {
    private const val PREFS = "yaadrakho"

    private fun prefs(c: Context) = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    // ---------- Tasks ----------

    fun tasks(c: Context): MutableList<Task> {
        val raw = prefs(c).getString("tasks", "[]") ?: "[]"
        val arr = JSONArray(raw)
        val out = mutableListOf<Task>()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            out.add(Task(o.getLong("id"), o.getString("title"), o.getLong("at"), o.optBoolean("done", false)))
        }
        return out
    }

    fun saveTasks(c: Context, list: List<Task>) {
        val arr = JSONArray()
        for (t in list) {
            arr.put(
                JSONObject()
                    .put("id", t.id)
                    .put("title", t.title)
                    .put("at", t.whenMs)
                    .put("done", t.done)
            )
        }
        prefs(c).edit().putString("tasks", arr.toString()).apply()
    }

    fun find(c: Context, id: Long): Task? = tasks(c).firstOrNull { it.id == id }

    fun markDone(c: Context, id: Long) {
        val all = tasks(c)
        all.firstOrNull { it.id == id }?.done = true
        saveTasks(c, all)
    }

    fun remove(c: Context, id: Long) {
        saveTasks(c, tasks(c).filter { it.id != id })
    }

    // ---------- Timetable ----------

    fun periods(c: Context, day: Int): String = prefs(c).getString("tt_$day", "") ?: ""

    fun setPeriods(c: Context, day: Int, text: String) {
        prefs(c).edit().putString("tt_$day", text.trim()).apply()
    }

    fun nightHour(c: Context): Int = prefs(c).getInt("night_h", 21)

    fun nightMinute(c: Context): Int = prefs(c).getInt("night_m", 0)

    fun setNight(c: Context, h: Int, m: Int) {
        prefs(c).edit().putInt("night_h", h).putInt("night_m", m).apply()
    }

    fun tomorrowText(c: Context): String {
        val cal = Calendar.getInstance()
        cal.add(Calendar.DAY_OF_YEAR, 1)
        val name = SimpleDateFormat("EEEE", Locale.ENGLISH).format(cal.time)
        val p = periods(c, cal.get(Calendar.DAY_OF_WEEK))
        return if (p.isEmpty()) {
            "No periods set for tomorrow ($name). Fill in your timetable in the app."
        } else {
            "Tomorrow ($name): $p. Pack these books in your bag."
        }
    }
}
