package com.rehan.yaadrakho

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

object Store {
    private const val PREFS = "yaadrakho"

    private fun prefs(c: Context) = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    // ---------- Tasks ----------

    fun tasks(c: Context): MutableList<Task> {
        val raw = prefs(c).getString("tasks", "[]") ?: "[]"
        val arr = JSONArray(raw)
        val out = mutableListOf<Task>()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            val at = o.getLong("at")
            out.add(
                Task(
                    id = o.getLong("id"),
                    title = o.getString("title"),
                    whenMs = at,
                    done = o.optBoolean("done", false),
                    category = o.optString("cat", Cat.HOMEWORK),
                    endMs = o.optLong("end", at + 3_600_000L),
                    deadlineMs = o.optLong("deadline", at),
                    needDays = o.optInt("need", 1)
                )
            )
        }
        return out
    }

    fun saveTasks(c: Context, list: List<Task>) {
        val arr = JSONArray()
        for (t in list) {
            arr.put(
                JSONObject()
                    .put("id", t.id)
                    .put("title", t.title)
                    .put("at", t.whenMs)
                    .put("done", t.done)
                    .put("cat", t.category)
                    .put("end", t.endMs)
                    .put("deadline", t.deadlineMs)
                    .put("need", t.needDays)
            )
        }
        prefs(c).edit().putString("tasks", arr.toString()).apply()
    }

    fun find(c: Context, id: Long): Task? = tasks(c).firstOrNull { it.id == id }

    fun add(c: Context, t: Task) {
        val all = tasks(c)
        all.add(t)
        saveTasks(c, all)
    }

    fun markDone(c: Context, id: Long) {
        val all = tasks(c)
        all.firstOrNull { it.id == id }?.done = true
        saveTasks(c, all)
    }

    fun remove(c: Context, id: Long) {
        saveTasks(c, tasks(c).filter { it.id != id })
    }

    // ---------- Timetable ----------

    fun slots(c: Context): MutableList<Slot> {
        val raw = prefs(c).getString("slots", "[]") ?: "[]"
        val arr = JSONArray(raw)
        val out = mutableListOf<Slot>()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            val m = mutableMapOf<Int, String>()
            val so = o.optJSONObject("subj")
            if (so != null) {
                val keys = so.keys()
                while (keys.hasNext()) {
                    val k = keys.next()
                    m[k.toInt()] = so.getString(k)
                }
            }
            out.add(Slot(o.getInt("s"), o.getInt("e"), o.optBoolean("b", false), m))
        }
        return out
    }

    fun saveSlots(c: Context, list: List<Slot>) {
        val arr = JSONArray()
        for (s in list) {
            val so = JSONObject()
            for ((k, v) in s.subj) so.put(k.toString(), v)
            arr.put(
                JSONObject()
                    .put("s", s.s)
                    .put("e", s.e)
                    .put("b", s.brk)
                    .put("subj", so)
            )
        }
        prefs(c).edit().putString("slots", arr.toString()).apply()
    }

    // Free time is calculated inside this window (minutes after midnight).
    fun windowStart(c: Context): Int = prefs(c).getInt("win_s", 7 * 60)

    fun windowEnd(c: Context): Int = prefs(c).getInt("win_e", 22 * 60)

    fun setWindow(c: Context, s: Int, e: Int) {
        prefs(c).edit().putInt("win_s", s).putInt("win_e", e).apply()
    }

    fun nightHour(c: Context): Int = prefs(c).getInt("night_h", 21)

    fun nightMinute(c: Context): Int = prefs(c).getInt("night_m", 0)

    fun setNight(c: Context, h: Int, m: Int) {
        prefs(c).edit().putInt("night_h", h).putInt("night_m", m).apply()
    }

    fun tomorrowText(c: Context): String {
        val cal = Calendar.getInstance()
        cal.add(Calendar.DAY_OF_YEAR, 1)
        val dow = cal.get(Calendar.DAY_OF_WEEK)
        val name = SimpleDateFormat("EEEE", Locale.ENGLISH).format(cal.time)
        val all = slots(c)
        if (all.isEmpty()) return "Set up your timetable in the Schedule tab."
        val subjects = all
            .filter { !it.brk }
            .mapNotNull { it.subj[dow] }
            .map { it.trim() }
            .filter { it.isNotEmpty() }
            .distinct()
        return if (subjects.isEmpty()) {
            "No classes tomorrow ($name)."
        } else {
            "Tomorrow ($name): " + subjects.joinToString(", ") + ". Pack these books in your bag."
        }
    }
}
