package com.rehan.yaadrakho

import android.Manifest
import android.app.Activity
import android.app.DatePickerDialog
import android.app.NotificationManager
import android.app.TimePickerDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Paint
import android.graphics.Typeface
import android.os.Build
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {

    private lateinit var titleInput: EditText
    private lateinit var dateBtn: Button
    private lateinit var timeBtn: Button
    private lateinit var list: LinearLayout

    private val picked: Calendar = Calendar.getInstance().apply {
        add(Calendar.HOUR_OF_DAY, 1)
        set(Calendar.MINUTE, 0)
        set(Calendar.SECOND, 0)
        set(Calendar.MILLISECOND, 0)
    }
    private val df = SimpleDateFormat("EEE, d MMM", Locale.ENGLISH)
    private val tf = SimpleDateFormat("hh:mm a", Locale.ENGLISH)

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val crash = getSharedPreferences("crash", MODE_PRIVATE).getString("trace", null)
        if (crash != null) {
            showCrash(crash)
            return
        }
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
        Notifier.ensureChannel(this)
        Scheduler.scheduleNight(this)
        buildUi()
    }

    override fun onResume() {
        super.onResume()
        if (::list.isInitialized) refresh()
    }

    private fun showCrash(trace: String) {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(24), dp(16), dp(24))
        }
        root.addView(TextView(this).apply {
            text = "The app crashed earlier. Send a screenshot of this screen to Claude."
            textSize = 16f
            setTypeface(typeface, Typeface.BOLD)
        })
        root.addView(Button(this).apply {
            text = "Clear error and open app"
            setOnClickListener {
                getSharedPreferences("crash", MODE_PRIVATE).edit().remove("trace").commit()
                recreate()
            }
        })
        root.addView(TextView(this).apply {
            text = trace.take(3000)
            textSize = 11f
            setTextIsSelectable(true)
        })
        setContentView(ScrollView(this).apply { addView(root) })
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(24), dp(16), dp(24))
        }
        setContentView(ScrollView(this).apply { addView(root) })

        root.addView(TextView(this).apply {
            text = "Yaad Rakho"
            textSize = 28f
            setTypeface(typeface, Typeface.BOLD)
        })

        titleInput = EditText(this).apply { hint = "What do you need to do? (e.g. PPS homework)" }
        root.addView(titleInput)

        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        dateBtn = Button(this).apply { setOnClickListener { pickDate() } }
        timeBtn = Button(this).apply { setOnClickListener { pickTime() } }
        row.addView(dateBtn, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        row.addView(timeBtn, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        root.addView(row)

        root.addView(Button(this).apply {
            text = "Add reminder"
            setOnClickListener { addTask() }
        })

        root.addView(TextView(this).apply {
            text = "Tasks"
            textSize = 20f
            setPadding(0, dp(24), 0, dp(8))
        })

        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(list)

        root.addView(Button(this).apply {
            text = "Timetable & nightly books reminder"
            setOnClickListener {
                startActivity(Intent(this@MainActivity, TimetableActivity::class.java))
            }
        })

        updateButtons()
    }

    private fun updateButtons() {
        dateBtn.text = df.format(picked.time)
        timeBtn.text = tf.format(picked.time)
    }

    private fun pickDate() {
        DatePickerDialog(
            this,
            DatePickerDialog.OnDateSetListener { _, y, m, d ->
                picked.set(y, m, d)
                updateButtons()
            },
            picked.get(Calendar.YEAR),
            picked.get(Calendar.MONTH),
            picked.get(Calendar.DAY_OF_MONTH)
        ).show()
    }

    private fun pickTime() {
        TimePickerDialog(
            this,
            TimePickerDialog.OnTimeSetListener { _, h, min ->
                picked.set(Calendar.HOUR_OF_DAY, h)
                picked.set(Calendar.MINUTE, min)
                updateButtons()
            },
            picked.get(Calendar.HOUR_OF_DAY),
            picked.get(Calendar.MINUTE),
            false
        ).show()
    }

    private fun addTask() {
        val title = titleInput.text.toString().trim()
        if (title.isEmpty()) {
            Toast.makeText(this, "Enter a task name first", Toast.LENGTH_SHORT).show()
            return
        }
        picked.set(Calendar.SECOND, 0)
        picked.set(Calendar.MILLISECOND, 0)
        val whenMs = picked.timeInMillis
        if (whenMs <= System.currentTimeMillis()) {
            Toast.makeText(this, "Pick a time in the future", Toast.LENGTH_SHORT).show()
            return
        }
        val t = Task(System.currentTimeMillis(), title, whenMs)
        val all = Store.tasks(this)
        all.add(t)
        Store.saveTasks(this, all)
        Scheduler.scheduleTask(this, t)
        titleInput.setText("")
        refresh()
        Toast.makeText(
            this,
            "Reminder set: " + df.format(picked.time) + ", " + tf.format(picked.time),
            Toast.LENGTH_SHORT
        ).show()
    }

    private fun deleteTask(t: Task) {
        Scheduler.cancelTask(this, t.id)
        getSystemService(NotificationManager::class.java).cancel(Scheduler.rc(t.id))
        Store.remove(this, t.id)
        refresh()
    }

    private fun refresh() {
        list.removeAllViews()
        val tasks = Store.tasks(this).sortedWith(compareBy<Task>({ it.done }, { it.whenMs }))
        if (tasks.isEmpty()) {
            list.addView(TextView(this).apply { text = "No tasks yet." })
            return
        }
        for (t in tasks) {
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(0, dp(8), 0, dp(8))
            }
            val label = TextView(this).apply {
                val d = Date(t.whenMs)
                text = (if (t.done) "[done] " else "") + t.title + "\n" + df.format(d) + ", " + tf.format(d)
                textSize = 16f
                if (t.done) paintFlags = paintFlags or Paint.STRIKE_THRU_TEXT_FLAG
            }
            val btns = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            if (!t.done) {
                btns.addView(Button(this).apply {
                    text = "Done"
                    setOnClickListener {
                        Store.markDone(this@MainActivity, t.id)
                        Scheduler.cancelTask(this@MainActivity, t.id)
                        getSystemService(NotificationManager::class.java).cancel(Scheduler.rc(t.id))
                        refresh()
                    }
                })
            }
            btns.addView(Button(this).apply {
                text = "Delete"
                setOnClickListener { deleteTask(t) }
            })
            row.addView(label)
            row.addView(btns)
            list.addView(row)
        }
    }
}
