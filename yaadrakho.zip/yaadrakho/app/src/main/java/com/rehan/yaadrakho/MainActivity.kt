package com.rehan.yaadrakho

import android.Manifest
import android.app.Activity
import android.content.pm.PackageManager
import android.graphics.Typeface
import android.os.Build
import android.os.Bundle
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class MainActivity : Activity() {

    private lateinit var content: FrameLayout
    private val navButtons = mutableListOf<Button>()
    private var tab = 0
    private var ready = false

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val crash = getSharedPreferences("crash", MODE_PRIVATE).getString("trace", null)
        if (crash != null) {
            showCrash(crash)
            return
        }
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
        Notifier.ensureChannel(this)
        Scheduler.scheduleNight(this)
        buildUi()
        ready = true
        show()
    }

    override fun onResume() {
        super.onResume()
        if (ready) show()
    }

    private fun buildUi() {
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL

        content = FrameLayout(this)
        root.addView(content, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))

        val nav = LinearLayout(this)
        nav.orientation = LinearLayout.HORIZONTAL
        val names = listOf("Today", "Schedule", "Tasks")
        for (i in names.indices) {
            val b = Button(this)
            b.text = names[i]
            b.setOnClickListener {
                tab = i
                show()
            }
            navButtons.add(b)
            nav.addView(b, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        }
        root.addView(
            nav,
            LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        )
        setContentView(root)
    }

    private fun show() {
        content.removeAllViews()
        val refresh: () -> Unit = { show() }
        val view = when (tab) {
            0 -> Screens.today(this, refresh)
            1 -> Screens.schedule(this, refresh)
            else -> Screens.tasks(this, refresh)
        }
        content.addView(view)
        for (i in navButtons.indices) {
            navButtons[i].setTextColor(if (i == tab) Ui.BLUE else Ui.MUTED)
        }
    }

    private fun showCrash(trace: String) {
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(dp(16), dp(24), dp(16), dp(24))

        val head = TextView(this)
        head.text = "The app crashed earlier. Send a screenshot of this screen to Claude."
        head.textSize = 16f
        head.setTypeface(head.typeface, Typeface.BOLD)
        root.addView(head)

        val clear = Button(this)
        clear.text = "Clear error and open app"
        clear.setOnClickListener {
            getSharedPreferences("crash", MODE_PRIVATE).edit().remove("trace").commit()
            recreate()
        }
        root.addView(clear)

        val body = TextView(this)
        body.text = trace.take(3000)
        body.textSize = 11f
        body.setTextIsSelectable(true)
        root.addView(body)

        val sv = ScrollView(this)
        sv.addView(root)
        setContentView(sv)
    }
}
